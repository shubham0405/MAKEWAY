﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class colorchangedup : MonoBehaviour {

    public Renderer rend;
    public Material[] mat;
    int chance;
   // public random_points r;
	// Use this for initialization
	void Start () {
        mat = new Material[2];
        mat[0] = Resources.Load("material/computer", typeof(Material)) as Material;
        mat[1] = Resources.Load("material/player",typeof(Material)) as Material;
        rend = GetComponent<Renderer>();
       // GameObject a=r.dots[0];
        //rend.enabled = true;

    }

    // Update is called once per frame
    void OnMouseDown()
    {
        if (Input.GetMouseButtonDown(0))
        {
           rend.material=mat[0];
        }

    }


}
